"""Global state tracking for pipeline runs."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class RunState:
    """Tracks the current state of a pipeline run."""

    status: str = "idle"  # idle | running | completed | failed
    current_stage: str = ""  # e.g., "Loading data", "Encoding embeddings"
    progress_pct: int = 0  # 0-100
    error_message: Optional[str] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None

    # Stage definitions with progress percentages
    STAGES = [
        ("Loading data", 0),
        ("Encoding embeddings", 20),
        ("Building features", 40),
        ("Baseline ranking", 60),
        ("Fairness reranking", 75),
        ("Computing metrics", 85),
        ("Generating plots", 95),
        ("Complete", 100),
    ]

    def update_stage(self, stage: str, progress: int) -> None:
        """Update current stage and progress."""
        self.current_stage = stage
        self.progress_pct = progress
        if self.status == "idle":
            self.status = "running"
            self.start_time = datetime.now()
            self.error_message = None

    def mark_complete(self) -> None:
        """Mark the run as completed."""
        self.status = "completed"
        self.current_stage = "Complete"
        self.progress_pct = 100
        self.end_time = datetime.now()
        self.error_message = None

    def mark_failed(self, error: str) -> None:
        """Mark the run as failed with an error message."""
        self.status = "failed"
        self.error_message = error
        self.end_time = datetime.now()

    def reset(self) -> None:
        """Reset state for a new run."""
        self.status = "idle"
        self.current_stage = ""
        self.progress_pct = 0
        self.error_message = None
        self.start_time = None
        self.end_time = None

    def to_dict(self) -> dict:
        """Convert state to dictionary for JSON response."""
        return {
            "status": self.status,
            "current_stage": self.current_stage,
            "progress_pct": self.progress_pct,
            "error_message": self.error_message,
            "start_time": self.start_time.isoformat() if self.start_time else None,
            "end_time": self.end_time.isoformat() if self.end_time else None,
        }
