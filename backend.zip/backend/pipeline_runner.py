"""Pipeline runner with progress tracking for backend."""

from __future__ import annotations

import config
from src.data.loader import load_freelancers, load_jobs
from src.data.preprocessing import prepare_freelancers, prepare_jobs
from src.evaluation.bias import compute_bias_metrics
from src.evaluation.metrics import compare_rankings
from src.features.feature_engineering import build_feature_table
from src.nlp.embedding import encode_corpus
from src.ranking.baseline import rank_baseline, save_ranking
from src.ranking.fairness import fair_rerank
from src.visualization.plots import generate_plots

from backend.state import RunState


def run_baseline_with_progress(state: RunState, mark_complete: bool = True):
    """Run baseline ranking with progress updates."""
    try:
        state.update_stage("Loading data", 0)
        freelancers = prepare_freelancers(load_freelancers())
        jobs = prepare_jobs(load_jobs())

        state.update_stage("Encoding embeddings", 20)
        freelancer_embeddings = encode_corpus(
            freelancers["text"].tolist(),
            cache_name="freelancer_embeddings.npy",
        )
        job_embeddings = encode_corpus(
            jobs["job_text"].tolist(),
            cache_name="job_embeddings.npy",
        )

        state.update_stage("Building features", 40)
        features = build_feature_table(freelancers, jobs, freelancer_embeddings, job_embeddings)

        state.update_stage("Baseline ranking", 60)
        baseline = rank_baseline(features)
        save_ranking(baseline, config.BASELINE_RANKING_CSV)

        if mark_complete:
            state.mark_complete()
        return baseline, freelancers, jobs
    except Exception as e:
        state.mark_failed(str(e))
        raise


def run_fairness_with_progress(
    state: RunState,
    baseline=None,
    freelancers=None,
    jobs=None,
    mark_complete: bool = True,
):
    """Run fairness reranking with progress updates."""
    try:
        if baseline is None or freelancers is None or jobs is None:
            baseline, freelancers, jobs = run_baseline_with_progress(state, mark_complete=False)

        state.update_stage("Fairness reranking", 75)
        fair = fair_rerank(baseline)
        save_ranking(fair, config.FAIR_RANKING_CSV)

        if mark_complete:
            state.mark_complete()
        return fair, baseline, freelancers, jobs
    except Exception as e:
        state.mark_failed(str(e))
        raise


def run_eval_with_progress(state: RunState, baseline=None, fair=None):
    """Run full evaluation with progress updates."""
    try:
        if baseline is None:
            baseline, freelancers, jobs = run_baseline_with_progress(state, mark_complete=False)
        else:
            state.update_stage("Loading data", 0)
            freelancers = prepare_freelancers(load_freelancers())
            jobs = prepare_jobs(load_jobs())

        if fair is None:
            fair, baseline, freelancers, jobs = run_fairness_with_progress(
                state, baseline, freelancers, jobs, mark_complete=False
            )

        state.update_stage("Computing metrics", 85)
        evaluation = compare_rankings(baseline, fair, k=config.TOP_K)
        bias = compute_bias_metrics(baseline, fair, k=config.TOP_K)

        config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        config.EVALUATION_METRICS_JSON.write_text(
            __import__("json").dumps(evaluation, indent=2), encoding="utf-8"
        )
        config.BIAS_METRICS_JSON.write_text(__import__("json").dumps(bias, indent=2), encoding="utf-8")

        state.update_stage("Generating plots", 95)
        generate_plots(baseline, fair, evaluation, bias)

        state.mark_complete()
    except Exception as e:
        state.mark_failed(str(e))
        raise
