"""Backend module for FastAPI application."""
